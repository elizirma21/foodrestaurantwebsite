<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <!-- Link CSS File -->
    <link rel="stylesheet" type="text/css" href="cssall/style.css">

    <title>Kitchenela Indonesia</title>
  </head>
  <body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top py-3" id="navbar">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 fs-5">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#menu">Menu</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#about">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Log Out</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="crudphp/index.php">Other</a>
        </li>
      </ul>
        <a  class="navbar-brand fw-bold mx-auto fs-4"><i class="fa-solid fa-fork-knife"></i></a>
        <button class="btn btn-lg btn-outline-warning px-5 rounded-pill ms-auto">Medan</button>
    </div>
  </div>
</nav>

  <!-- Home -->
  <section id="home" class="d-flex">
    <div class="container d-flex align-items-center">
      <div class="row justify-content-center">
        <div class="col-md-6">
          <h1 class="display-1 fw-bolder text-white text-center">Kitchenela <span class="text-warning">Indonesia</span ></h1>
        </div>
      </div>
    </div>
  </section>

      <!-- MENU -->
    <section id="menu" class="pt-3">
      <div class="container">
       <div class="row mb-5">
         <div class="col-12 text-center">
          <h3 class="text-warning">Masakan Indonesia</h3>
          <h2 class="display-5 fw-bold">Menu Andalan</h2>
         </div>
       </div>
       <div class="row">
         <div class="col-md-6">
           <div class="card mb-3 border-0">
  <div class="row g-0">
    <div class="col-md-5 d-flex align-items-center">
      <img src="img/menu1.jpg" class="img-fluid" alt="...">
    </div>
    <div class="col-md-7">
          <div class="card-body">
            <h5 class="card-title fs-3 fw-bold">Indomie Becek</h5>
            <p class="card-text lead mb-2">Menu andalan kitchenela indomie dengan telur mata sapi</p>
            <p class="lead fw-bold fs-4 text-warning">Rp. 15.000</p>
        </div>
      </div>
    </div>
  </div>
</div>
 <div class="col-md-6">
           <div class="card mb-3 border-0">
  <div class="row g-0">
    <div class="col-md-5 d-flex align-items-center">
      <img src="img/menu2.jpg" class="img-fluid" alt="...">
    </div>
    <div class="col-md-7">
          <div class="card-body">
            <h5 class="card-title fs-3 fw-bold">Soto Betawi</h5>
            <p class="card-text lead mb-2">Makanan khas betawi yaitu kuah soto dan ceker dengan bawang goreng.</p>
            <p class="lead fw-bold fs-4 text-warning">Rp. 18.000</p>
        </div>
      </div>
    </div>
  </div>
</div>
 <div class="col-md-6">
           <div class="card mb-3 border-0">
  <div class="row g-0">
    <div class="col-md-5 d-flex align-items-center">
      <img src="img/menu3.jpg" class="img-fluid" alt="...">
    </div>
    <div class="col-md-7">
          <div class="card-body">
            <h5 class="card-title fs-3 fw-bold">Ayam Penyet Bakar</h5>
            <p class="card-text lead mb-2">Ayam Penyet dengan bumbu bakar dan sambal terasi</p>
            <p class="lead fw-bold fs-4 text-warning">Rp. 12.000</p>
        </div>
      </div>
    </div>
  </div>
</div>
 <div class="col-md-6">
           <div class="card mb-3 border-0">
  <div class="row g-0">
    <div class="col-md-5 d-flex align-items-center">
      <img src="img/menu4.jpg" class="img-fluid" alt="...">
    </div>
    <div class="col-md-7">
          <div class="card-body">
            <h5 class="card-title fs-3 fw-bold">Ikan Kakap Gulai</h5>
            <p class="card-text lead mb-2">Ikan kakap yang di masak dengan hati kemudian dicampur kuah gulai kuning.</p>
            <p class="lead fw-bold fs-4 text-warning">Rp. 25.000</p>
        </div>
      </div>
    </div>
  </div>
</div>
 <div class="col-md-6">
           <div class="card mb-3 border-0">
  <div class="row g-0">
    <div class="col-md-5 d-flex align-items-center">
      <img src="img/menu5.jpg" class="img-fluid" alt="...">
    </div>
    <div class="col-md-7">
          <div class="card-body">
            <h5 class="card-title fs-3 fw-bold">Kopi Hitam</h5>
            <p class="card-text lead mb-2">Kopi hitam tanpa ampas.</p>
            <p class="lead fw-bold fs-4 text-warning">Rp. 8.000</p>
        </div>
      </div>
    </div>
  </div>
</div>
 <div class="col-md-6">
           <div class="card mb-3 border-0">
  <div class="row g-0">
    <div class="col-md-5 d-flex align-items-center">
      <img src="img/menu6.jpg" class="img-fluid" alt="...">
    </div>
    <div class="col-md-7">
          <div class="card-body">
            <h5 class="card-title fs-3 fw-bold">Es Kopi Susu</h5>
            <p class="card-text lead mb-2">Kopi hitam dicampur dengan susu yang diambil langsung dari sapi.</p>
            <p class="lead fw-bold fs-4 text-warning">Rp. 7.000</p>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="col-md-6">
           <div class="card mb-3 border-0">
  <div class="row g-0">
    <div class="col-md-5 d-flex align-items-center">
      <img src="img/menu7.jpg" class="img-fluid" alt="...">
    </div>
    <div class="col-md-7">
          <div class="card-body">
            <h5 class="card-title fs-3 fw-bold">Teh Jasmin</h5>
            <p class="card-text lead mb-2">Teh jasmin dengan rasa jasmin yang membuat kamu tenang.</p>
            <p class="lead fw-bold fs-4 text-warning">Rp. 10.000</p>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="col-md-6">
           <div class="card mb-3 border-0">
  <div class="row g-0">
    <div class="col-md-5 d-flex align-items-center">
      <img src="img/menu8.jpg" class="img-fluid" alt="...">
    </div>
    <div class="col-md-7">
          <div class="card-body">
            <h5 class="card-title fs-3 fw-bold">Es Cendol</h5>
            <p class="card-text lead mb-2">Es cendol dengan gula aren manis dan cendol hijau.</p>
            <p class="lead fw-bold fs-4 text-warning">Rp. 6.000</p>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="col-md-6">
           <div class="card mb-3 border-0">
  <div class="row g-0">
    <div class="col-md-5 d-flex align-items-center">
      <img src="img/menu9.jpg" class="img-fluid" alt="...">
    </div>
    <div class="col-md-7">
          <div class="card-body">
            <h5 class="card-title fs-3 fw-bold">Wedang Uwuh</h5>
            <p class="card-text lead mb-2">Minuman khas jawa dengan bumbu jahe dan kunyit.</p>
            <p class="lead fw-bold fs-4 text-warning">Rp. 9.000</p>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="col-md-6">
           <div class="card mb-3 border-0">
  <div class="row g-0">
    <div class="col-md-5 d-flex align-items-center">
      <img src="img/menu10.jpeg" class="img-fluid" alt="...">
    </div>
    <div class="col-md-7">
          <div class="card-body">
            <h5 class="card-title fs-3 fw-bold">Es Pisang Ijo</h5>
            <p class="card-text lead mb-2">Makanan has sulawesi yaitu es pisang ijo dengan adanya susu dan gula aren.</p>
            <p class="lead fw-bold fs-4 text-warning">Rp. 10.000</p>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
    </section>

     <!-- About Us -->
    <section id="about" class="pt-3">
      <div class="container my-5 py-5">
        <div class="row">
          <div class="col-md-6">
            <img src="img/aboutus.jpg" alt="" class="w-100 h-75">
          </div>
          <div class="col-md-6">
            <h3 class="text-warning mt-4">About Us</h3>
          <h2 class="display-5 fw-bold mb-4">The Best Warung About Indonesia's Food</h2>
          <p class="lead">Selama 5 tahun kedai kopi paling terkenal di Medan berkembang di Medan sebagai titik siap untuk berita, diskusi, dan faksi. 
          Kitchenela mempunyai prinsip kebahagiaan customer itu adalah nomor 1. Jadi, bagi kami adalah kepuasan pelanggan ada diatas segalanya.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Chef Hebat -->
    <section id="team" class="pt-3">
      <div class="container">
        <div class="row mb-5">
          <div class="col-12 text-center">
            <h3 class="text-warning">Our Chef</h3>
            <h2 class="display-5 fw fw-bold">Chef Terbaik di Indonesia.</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3">
            <div class="card border-0">
                <img src="img/chef1.jpeg" class="card-img-top" alt="...">
            <div class="card-body text-center">
                <h5 class="card-title">Renata Moellek</h5>
                 <p class="card-text lead">Masterchef Indonesia's Chef</p>
          </div>
          </div>
          </div>
          <div class="col-md-3">
            <div class="card border-0 h-100">
                <img src="img/chef2.jpg" class="card-img-top h-100" alt="...">
            <div class="card-body text-center">
                <h5 class="card-title">Arnold Poernomo</h5>
                 <p class="card-text lead">Masterchef Indonesia's Chef</p>
          </div>
          </div>
          </div>
          <div class="col-md-3">
            <div class="card border-0">
                <img src="img/chef3.jpg" class="card-img-top" alt="...">
            <div class="card-body text-center">
                <h5 class="card-title">Juna Rorimpadey</h5>
                 <p class="card-text lead">Masterchef Indonesia's Chef</p>
          </div>
          </div>
          </div>
          <div class="col-md-3">
            <div class="card border-0">
                <img src="img/chef4.jpg" class="card-img-top" alt="...">
            <div class="card-body text-center">
                <h5 class="card-title">Farah Quinn</h5>
                 <p class="card-text lead">Masterchef Indonesia's Chef</p>
          </div>
          </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Contact -->
    <section id="contact" class="pt-3">
      <div class="container my-5 py-5">
        <div class="row mb-5">
          <div class="col-12 text-center">
            <h3 class="text-warning">Contact</h3>
            <h2 class="display-5 fw fw-bold">Have Some Questions?</h2>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-md-6">
            <form action="">
              <div class="mb-3">
                  <input type="text" class="form-control py-2" id="name" placeholder="Your Name">
              </div>
               <div class="mb-3">
                  <input type="text" class="form-control py-2" id="sub" placeholder="Subject">
              </div>
              <div class="mb-3">
                  <input type="email" class="form-control py-2" id="exampleFormControlInput1" placeholder="Your Email">
              </div>
              <div class="mb-3">
                  <textarea class="form-control" id="exampleFormControlTextarea1" rows="5" placeholder="Your Message"></textarea>
              </div>
              <button class="btn btn-outline-warning px-3">Submit Message</button>
            </form>
          </div>
        </div>
      </div>
    </section>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <script>
      window.onscroll = function(){
        scrollFunction();
      }

      function scrollFunction(){
        if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
          document.getElementById("navbar").classList.add("bg-dark", "shadow");
        }else{
          document.getElementById("navbar").classList.remove("bg-dark", "shadow");
        }
      }
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>